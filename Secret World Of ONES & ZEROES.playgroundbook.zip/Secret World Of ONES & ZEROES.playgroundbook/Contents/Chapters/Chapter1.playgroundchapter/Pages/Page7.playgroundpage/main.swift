/*:
 # Save The World
 ----
 Congratulations!🥳
 
 You complete this Playground with no effort.👍
 
 you have learned:
 
 1️⃣.Binary system
 
 2️⃣.Conver binary to denary
 
 3️⃣.Look up the ASCII Table
 
 4️⃣.Nest functions
 
 5️⃣.Get information from a complex binary string
 
 More importantly, you saved the world!🎉
 
 After you learn about the Secret World Of ONES & ZEROES, you become more curious about the larger Secret World of COMPUTER SCIENCE.
 
 There must be a larger organization behind those two computers...🧐
 
 
 >Don't you wonder what ComputerA said before they were broken?🤣
 >
 >Copy the following code and paste it on page 5 to translate!⬇️🤣
*/

//ComputerA🤖：010010000110010101111001001000000101001101101001011100100110100100100001

//#-hidden-code
import PlaygroundSupport
PlaygroundPage.current.assessmentStatus = .pass(message: """
"hey bro, Do you know who broke my computer?🤬"

"It's not me!I don't know.🤫"
""")
//#-end-hidden-code




