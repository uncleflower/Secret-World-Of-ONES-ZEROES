//#-hidden-code
func inputCode() {
    
}
import PlaygroundSupport
PlaygroundPage.current.assessmentStatus = .pass(message: """
Congratulations! You save the world!
[next page](@next)
""")
//#-end-hidden-code
/*:
 # Break the computer
 ----
 When you walk into that lab, the two computers🤖 are still "talking"
 
 ComputerA🤖：010010000110010101111001001000000101001101101001011100100110100100100001
 
 ComputerB🤖：....
 
 
 You sneak up and open the terminal, input rm -rf /💀
*/
//input inputCode()



